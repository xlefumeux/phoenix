[root@harbor01 ccohen]# dnf install podman
Failed to set locale, defaulting to C.UTF-8
Updating Subscription Management repositories.
Last metadata expiration check: 1:52:40 ago on Thu Aug 12 14:26:46 2021.
Dependencies resolved.
==================================================================================================================================================
 Package                           Architecture Version                                              Repository                              Size
==================================================================================================================================================
Installing:
 podman                            x86_64       3.2.3-0.10.module+el8.4.0+11989+6676f7ad             rhel-8-for-x86_64-appstream-rpms        12 M
Installing dependencies:
 conmon                            x86_64       2:2.0.29-1.module+el8.4.0+11822+6cc1e7d7             rhel-8-for-x86_64-appstream-rpms        52 k
 container-selinux                 noarch       2:2.164.1-1.module+el8.4.0+11870+8b6f7018            rhel-8-for-x86_64-appstream-rpms        52 k
 containernetworking-plugins       x86_64       0.9.1-1.module+el8.4.0+11822+6cc1e7d7                rhel-8-for-x86_64-appstream-rpms        20 M
 containers-common                 x86_64       1:1.3.1-5.module+el8.4.0+11990+22932769              rhel-8-for-x86_64-appstream-rpms        95 k
 criu                              x86_64       3.15-1.module+el8.4.0+11822+6cc1e7d7                 rhel-8-for-x86_64-appstream-rpms       511 k
 fuse-overlayfs                    x86_64       1.6-1.module+el8.4.0+11822+6cc1e7d7                  rhel-8-for-x86_64-appstream-rpms        73 k
 fuse3                             x86_64       3.2.1-12.el8                                         rhel-8-for-x86_64-baseos-rpms           50 k
 fuse3-libs                        x86_64       3.2.1-12.el8                                         rhel-8-for-x86_64-baseos-rpms           94 k
 libnet                            x86_64       1.1.6-15.el8                                         rhel-8-for-x86_64-appstream-rpms        67 k
 libslirp                          x86_64       4.3.1-1.module+el8.4.0+11822+6cc1e7d7                rhel-8-for-x86_64-appstream-rpms        69 k
 podman-catatonit                  x86_64       3.2.3-0.10.module+el8.4.0+11989+6676f7ad             rhel-8-for-x86_64-appstream-rpms       325 k
 runc                              x86_64       1.0.0-74.rc95.module+el8.4.0+11822+6cc1e7d7          rhel-8-for-x86_64-appstream-rpms       3.3 M
 slirp4netns                       x86_64       1.1.8-1.module+el8.4.0+11822+6cc1e7d7                rhel-8-for-x86_64-appstream-rpms        51 k
Enabling module streams:
 container-tools                                rhel8                                                                                            

Transaction Summary
==================================================================================================================================================
Install  14 Packages

Total download size: 37 M
Installed size: 129 M
Is this ok [y/N]: y
Downloading Packages:
(1/14): fuse3-libs-3.2.1-12.el8.x86_64.rpm                                                                        184 kB/s |  94 kB     00:00    
(2/14): fuse3-3.2.1-12.el8.x86_64.rpm                                                                              95 kB/s |  50 kB     00:00    
(3/14): libnet-1.1.6-15.el8.x86_64.rpm                                                                            119 kB/s |  67 kB     00:00    
(4/14): containers-common-1.3.1-5.module+el8.4.0+11990+22932769.x86_64.rpm                                        375 kB/s |  95 kB     00:00    
(5/14): fuse-overlayfs-1.6-1.module+el8.4.0+11822+6cc1e7d7.x86_64.rpm                                             263 kB/s |  73 kB     00:00    
(6/14): container-selinux-2.164.1-1.module+el8.4.0+11870+8b6f7018.noarch.rpm                                      169 kB/s |  52 kB     00:00    
(7/14): libslirp-4.3.1-1.module+el8.4.0+11822+6cc1e7d7.x86_64.rpm                                                 231 kB/s |  69 kB     00:00    
(8/14): criu-3.15-1.module+el8.4.0+11822+6cc1e7d7.x86_64.rpm                                                      1.2 MB/s | 511 kB     00:00    
(9/14): runc-1.0.0-74.rc95.module+el8.4.0+11822+6cc1e7d7.x86_64.rpm                                               6.8 MB/s | 3.3 MB     00:00    
(10/14): conmon-2.0.29-1.module+el8.4.0+11822+6cc1e7d7.x86_64.rpm                                                 186 kB/s |  52 kB     00:00    
(11/14): slirp4netns-1.1.8-1.module+el8.4.0+11822+6cc1e7d7.x86_64.rpm                                             187 kB/s |  51 kB     00:00    
(12/14): podman-catatonit-3.2.3-0.10.module+el8.4.0+11989+6676f7ad.x86_64.rpm                                     1.0 MB/s | 325 kB     00:00    
(13/14): podman-3.2.3-0.10.module+el8.4.0+11989+6676f7ad.x86_64.rpm                                                14 MB/s |  12 MB     00:00    
(14/14): containernetworking-plugins-0.9.1-1.module+el8.4.0+11822+6cc1e7d7.x86_64.rpm                              18 MB/s |  20 MB     00:01    
--------------------------------------------------------------------------------------------------------------------------------------------------
Total                                                                                                              13 MB/s |  37 MB     00:02     
Running transaction check
Transaction check succeeded.
Running transaction test
Transaction test succeeded.
Running transaction
  Preparing        :                                                                                                                          1/1 
  Installing       : containernetworking-plugins-0.9.1-1.module+el8.4.0+11822+6cc1e7d7.x86_64                                                1/14 
  Installing       : conmon-2:2.0.29-1.module+el8.4.0+11822+6cc1e7d7.x86_64                                                                  2/14 
  Installing       : libslirp-4.3.1-1.module+el8.4.0+11822+6cc1e7d7.x86_64                                                                   3/14 
  Installing       : slirp4netns-1.1.8-1.module+el8.4.0+11822+6cc1e7d7.x86_64                                                                4/14 
  Running scriptlet: container-selinux-2:2.164.1-1.module+el8.4.0+11870+8b6f7018.noarch                                                      5/14 
  Installing       : container-selinux-2:2.164.1-1.module+el8.4.0+11870+8b6f7018.noarch                                                      5/14 
  Running scriptlet: container-selinux-2:2.164.1-1.module+el8.4.0+11870+8b6f7018.noarch                                                      5/14 
  Installing       : libnet-1.1.6-15.el8.x86_64                                                                                              6/14 
  Running scriptlet: libnet-1.1.6-15.el8.x86_64                                                                                              6/14 
  Installing       : criu-3.15-1.module+el8.4.0+11822+6cc1e7d7.x86_64                                                                        7/14 
  Installing       : runc-1.0.0-74.rc95.module+el8.4.0+11822+6cc1e7d7.x86_64                                                                 8/14 
  Installing       : fuse3-3.2.1-12.el8.x86_64                                                                                               9/14 
  Installing       : fuse3-libs-3.2.1-12.el8.x86_64                                                                                         10/14 
  Running scriptlet: fuse3-libs-3.2.1-12.el8.x86_64                                                                                         10/14 
  Installing       : fuse-overlayfs-1.6-1.module+el8.4.0+11822+6cc1e7d7.x86_64                                                              11/14 
  Running scriptlet: fuse-overlayfs-1.6-1.module+el8.4.0+11822+6cc1e7d7.x86_64                                                              11/14 
  Installing       : containers-common-1:1.3.1-5.module+el8.4.0+11990+22932769.x86_64                                                       12/14 
  Installing       : podman-catatonit-3.2.3-0.10.module+el8.4.0+11989+6676f7ad.x86_64                                                       13/14 
  Installing       : podman-3.2.3-0.10.module+el8.4.0+11989+6676f7ad.x86_64                                                                 14/14 
  Running scriptlet: container-selinux-2:2.164.1-1.module+el8.4.0+11870+8b6f7018.noarch                                                     14/14 
  Running scriptlet: podman-3.2.3-0.10.module+el8.4.0+11989+6676f7ad.x86_64                                                                 14/14 
  Verifying        : fuse3-libs-3.2.1-12.el8.x86_64                                                                                          1/14 
  Verifying        : fuse3-3.2.1-12.el8.x86_64                                                                                               2/14 
  Verifying        : libnet-1.1.6-15.el8.x86_64                                                                                              3/14 
  Verifying        : containers-common-1:1.3.1-5.module+el8.4.0+11990+22932769.x86_64                                                        4/14 
  Verifying        : fuse-overlayfs-1.6-1.module+el8.4.0+11822+6cc1e7d7.x86_64                                                               5/14 
  Verifying        : container-selinux-2:2.164.1-1.module+el8.4.0+11870+8b6f7018.noarch                                                      6/14 
  Verifying        : criu-3.15-1.module+el8.4.0+11822+6cc1e7d7.x86_64                                                                        7/14 
  Verifying        : libslirp-4.3.1-1.module+el8.4.0+11822+6cc1e7d7.x86_64                                                                   8/14 
  Verifying        : runc-1.0.0-74.rc95.module+el8.4.0+11822+6cc1e7d7.x86_64                                                                 9/14 
  Verifying        : podman-3.2.3-0.10.module+el8.4.0+11989+6676f7ad.x86_64                                                                 10/14 
  Verifying        : conmon-2:2.0.29-1.module+el8.4.0+11822+6cc1e7d7.x86_64                                                                 11/14 
  Verifying        : slirp4netns-1.1.8-1.module+el8.4.0+11822+6cc1e7d7.x86_64                                                               12/14 
  Verifying        : podman-catatonit-3.2.3-0.10.module+el8.4.0+11989+6676f7ad.x86_64                                                       13/14 
  Verifying        : containernetworking-plugins-0.9.1-1.module+el8.4.0+11822+6cc1e7d7.x86_64                                               14/14 
Installed products updated.

Installed:
  conmon-2:2.0.29-1.module+el8.4.0+11822+6cc1e7d7.x86_64                     container-selinux-2:2.164.1-1.module+el8.4.0+11870+8b6f7018.noarch  
  containernetworking-plugins-0.9.1-1.module+el8.4.0+11822+6cc1e7d7.x86_64   containers-common-1:1.3.1-5.module+el8.4.0+11990+22932769.x86_64    
  criu-3.15-1.module+el8.4.0+11822+6cc1e7d7.x86_64                           fuse-overlayfs-1.6-1.module+el8.4.0+11822+6cc1e7d7.x86_64           
  fuse3-3.2.1-12.el8.x86_64                                                  fuse3-libs-3.2.1-12.el8.x86_64                                      
  libnet-1.1.6-15.el8.x86_64                                                 libslirp-4.3.1-1.module+el8.4.0+11822+6cc1e7d7.x86_64               
  podman-3.2.3-0.10.module+el8.4.0+11989+6676f7ad.x86_64                     podman-catatonit-3.2.3-0.10.module+el8.4.0+11989+6676f7ad.x86_64    
  runc-1.0.0-74.rc95.module+el8.4.0+11822+6cc1e7d7.x86_64                    slirp4netns-1.1.8-1.module+el8.4.0+11822+6cc1e7d7.x86_64            

Complete!


root@harbor01 containers]# pvcreate /dev/sdb
  Physical volume "/dev/sdb" successfully created.
[root@harbor01 containers]# vgcreate datavg /dev/sdb
  Volume group "datavg" successfully created
[root@harbor01 containers]# lvcreate -l50%VG -ncontainerslv datavg
  Logical volume "containerslv" created.
[root@harbor01 containers]# lvs
  LV           VG     Attr       LSize   Pool Origin Data%  Meta%  Move Log Cpy%Sync Convert
  containerslv datavg -wi-a----- <50.00g                                              

  [root@harbor01 containers]# mkfs.xfs /dev/datavg/containerslv 
meta-data=/dev/datavg/containerslv isize=512    agcount=4, agsize=3276544 blks
         =                       sectsz=512   attr=2, projid32bit=1
         =                       crc=1        finobt=1, sparse=1, rmapbt=0
         =                       reflink=1
data     =                       bsize=4096   blocks=13106176, imaxpct=25
         =                       sunit=0      swidth=0 blks
naming   =version 2              bsize=4096   ascii-ci=0, ftype=1
log      =internal log           bsize=4096   blocks=6399, version=2
         =                       sectsz=512   sunit=0 blks, lazy-count=1
realtime =none                   extsz=4096   blocks=0, rtextents=0
Discarding blocks...Done.

[root@harbor01 containers]# echo "/dev/mapper/datavg-containerslv /var/lib/containers/storage xfs defaults 0 0" >> /etc/fstab 
[root@harbor01 containers]# mount -a
[root@harbor01 containers]# df -hT /var/lib/containers/storage/
Filesystem                      Type  Size  Used Avail Use% Mounted on
/dev/mapper/datavg-containerslv xfs    50G  390M   50G   1% /var/lib/containers/storage
[root@harbor01 containers]# 



 dnf install podman-compose
Failed to set locale, defaulting to C.UTF-8
Updating Subscription Management repositories.
Last metadata expiration check: 3:11:25 ago on Thu Aug 12 14:26:46 2021.
Dependencies resolved.
==================================================================================================================================================
 Package                   Architecture      Version                                            Repository                                   Size
==================================================================================================================================================
Installing:
 podman-compose            noarch            0.1.7-2.git20201120.el8                            epel                                         49 k
Installing dependencies:
 python3-pip               noarch            9.0.3-19.el8                                       rhel-8-for-x86_64-appstream-rpms             20 k
 python36                  x86_64            3.6.8-2.module+el8.1.0+3334+5cb623d7               rhel-8-for-x86_64-appstream-rpms             19 k
Enabling module streams:
 python36                                    3.6                                                                                                 

Transaction Summary
==================================================================================================================================================
Install  3 Packages

Total download size: 88 k
Installed size: 140 k
Is this ok [y/N]: y
Downloading Packages:
(1/3): podman-compose-0.1.7-2.git20201120.el8.noarch.rpm                                                          250 kB/s |  49 kB     00:00    
(2/3): python36-3.6.8-2.module+el8.1.0+3334+5cb623d7.x86_64.rpm                                                    59 kB/s |  19 kB     00:00    
(3/3): python3-pip-9.0.3-19.el8.noarch.rpm                                                                         51 kB/s |  20 kB     00:00    
--------------------------------------------------------------------------------------------------------------------------------------------------
Total                                                                                                              74 kB/s |  88 kB     00:01     
Running transaction check
Transaction check succeeded.
Running transaction test
Transaction test succeeded.
Running transaction
  Preparing        :                                                                                                                          1/1 
  Installing       : python3-pip-9.0.3-19.el8.noarch                                                                                          1/3 
  Installing       : python36-3.6.8-2.module+el8.1.0+3334+5cb623d7.x86_64                                                                     2/3 
  Running scriptlet: python36-3.6.8-2.module+el8.1.0+3334+5cb623d7.x86_64                                                                     2/3 
  Installing       : podman-compose-0.1.7-2.git20201120.el8.noarch                                                                            3/3 
  Running scriptlet: podman-compose-0.1.7-2.git20201120.el8.noarch                                                                            3/3 
  Verifying        : podman-compose-0.1.7-2.git20201120.el8.noarch                                                                            1/3 
  Verifying        : python36-3.6.8-2.module+el8.1.0+3334+5cb623d7.x86_64                                                                     2/3 
  Verifying        : python3-pip-9.0.3-19.el8.noarch                                                                                          3/3 
Installed products updated.

Installed:
  podman-compose-0.1.7-2.git20201120.el8.noarch     python3-pip-9.0.3-19.el8.noarch     python36-3.6.8-2.module+el8.1.0+3334+5cb623d7.x86_64    

Complete!
[root@harbor01 ~]# 


[root@harbor01 ~]# lvcreate -l50%VG -nharborlv datavg
  Logical volume "harborlv" created.
[root@harbor01 ~]# mkfs.xfs /dev/datavg/harborlv 
meta-data=/dev/datavg/harborlv   isize=512    agcount=4, agsize=3276544 blks
         =                       sectsz=512   attr=2, projid32bit=1
         =                       crc=1        finobt=1, sparse=1, rmapbt=0
         =                       reflink=1
data     =                       bsize=4096   blocks=13106176, imaxpct=25
         =                       sunit=0      swidth=0 blks
naming   =version 2              bsize=4096   ascii-ci=0, ftype=1
log      =internal log           bsize=4096   blocks=6399, version=2
         =                       sectsz=512   sunit=0 blks, lazy-count=1
realtime =none                   extsz=4096   blocks=0, rtextents=0
Discarding blocks...Done.
[root@harbor01 ~]# cat /etc/fstab 

#
# /etc/fstab
# Created by anaconda on Sun May 16 17:14:22 2021
#
# Accessible filesystems, by reference, are maintained under '/dev/disk/'.
# See man pages fstab(5), findfs(8), mount(8) and/or blkid(8) for more info.
#
# After editing this file, run 'systemctl daemon-reload' to update systemd
# units generated from this file.
#
UUID=b8a0ba71-af92-4e34-af8b-53e5016bb947 /                       xfs     defaults        0 0
UUID=aeab582a-6ede-4f9c-96dd-2b887868a749 /boot                   xfs     defaults        0 0
UUID=2EB8-5680          /boot/efi               vfat    umask=0077,shortname=winnt 0 2
/dev/mapper/datavg-containerslv /var/lib/containers/storage xfs defaults 0 0
[root@harbor01 ~]# #echo "/dev/mapper/datavg-harborlv /apps/harbor xfs defaults 0 0" >> /etc/fstab 
[root@harbor01 ~]# mkdir -p /apps/harbor
[root@harbor01 ~]# echo "/dev/mapper/datavg-harborlv /apps/harbor xfs defaults 0 0" >> /etc/fstab 
[root@harbor01 ~]# mount -a
[root@harbor01 ~]# df -hT /apps/harbor/
Filesystem                  Type  Size  Used Avail Use% Mounted on
/dev/mapper/datavg-harborlv xfs    50G  390M   50G   1% /apps/harbor
[root@harbor01 ~]# 

root@harbor01 ~]# cd /apps/harbor/
[root@harbor01 harbor]# ll
total 0
[root@harbor01 harbor]# wget https://github.com/goharbor/harbor/releases/download/v2.3.1/harbor-offline-installer-v2.3.1.tgz
--2021-08-12 17:46:30--  https://github.com/goharbor/harbor/releases/download/v2.3.1/harbor-offline-installer-v2.3.1.tgz
Resolving github.com (github.com)... 140.82.121.3
Connecting to github.com (github.com)|140.82.121.3|:443... ^C
[root@harbor01 harbor]# wget https://github.com/goharbor/harbor/releases/download/v2.3.1/harbor-offline-installer-v2.3.1.tgz
--2021-08-12 17:46:44--  https://github.com/goharbor/harbor/releases/download/v2.3.1/harbor-offline-installer-v2.3.1.tgz
Resolving github.com (github.com)... 140.82.121.3
Connecting to github.com (github.com)|140.82.121.3|:443... connected.
HTTP request sent, awaiting response... 302 Found
Location: https://github-releases.githubusercontent.com/50613991/3b2aa7d9-52e1-4845-848b-c0f422d1fd69?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAIWNJYAX4CSVEH53A%2F20210812%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20210812T154645Z&X-Amz-Expires=300&X-Amz-Signature=bc9689af7072c7cddd272427aab7cd2386dfe2d9c0c6ae3564c8778706bef862&X-Amz-SignedHeaders=host&actor_id=0&key_id=0&repo_id=50613991&response-content-disposition=attachment%3B%20filename%3Dharbor-offline-installer-v2.3.1.tgz&response-content-type=application%2Foctet-stream [following]
--2021-08-12 17:46:45--  https://github-releases.githubusercontent.com/50613991/3b2aa7d9-52e1-4845-848b-c0f422d1fd69?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAIWNJYAX4CSVEH53A%2F20210812%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20210812T154645Z&X-Amz-Expires=300&X-Amz-Signature=bc9689af7072c7cddd272427aab7cd2386dfe2d9c0c6ae3564c8778706bef862&X-Amz-SignedHeaders=host&actor_id=0&key_id=0&repo_id=50613991&response-content-disposition=attachment%3B%20filename%3Dharbor-offline-installer-v2.3.1.tgz&response-content-type=application%2Foctet-stream
Resolving github-releases.githubusercontent.com (github-releases.githubusercontent.com)... 185.199.111.154, 185.199.108.154, 185.199.109.154, ...
Connecting to github-releases.githubusercontent.com (github-releases.githubusercontent.com)|185.199.111.154|:443... connected.
HTTP request sent, awaiting response... 200 OK
Length: 629571428 (600M) [application/octet-stream]
Saving to: 'harbor-offline-installer-v2.3.1.tgz'

harbor-offline-installer-v2.3.1.tgz  100%[====================================================================>] 600.41M  71.6MB/s    in 8.9s    

2021-08-12 17:46:54 (67.7 MB/s) - 'harbor-offline-installer-v2.3.1.tgz' saved [629571428/629571428]

[root@harbor01 harbor]# 
[root@harbor01 harbor]# tar xvfz harbor-offline-installer-v2.3.1.tgz 
harbor/harbor.v2.3.1.tar.gz
harbor/prepare
harbor/LICENSE
harbor/install.sh
harbor/common.sh
harbor/harbor.yml.tmpl
[root@harbor01 harbor]# ls 
harbor  harbor-offline-installer-v2.3.1.tgz
[root@harbor01 harbor]# cd harbor/
[root@harbor01 harbor]# 



certs 


 openssl req -x509 -new -nodes -sha512 -days 3650 \
  -subj "/C=FR/ST=PACA/L=Sophia/O=SSG/OU=IT/CN=p.cohenc.fr" \
  -key ca.key \
  -out ca.crt

openssl genrsa -out harbor01.p.cohenc.fr.key 4096

openssl req -sha512 -new -subj "/C=FR/ST=PACA/L=Sophia/O=SSG/OU=IT/CN=harbor01.p.cohenc.fr" -key harbor01.p.cohenc.fr.key -out harbor01.p.cohenc.fr.csr


cat > v3.ext <<-EOF
authorityKeyIdentifier=keyid,issuer
basicConstraints=CA:FALSE
keyUsage = digitalSignature, nonRepudiation, keyEncipherment, dataEncipherment
extendedKeyUsage = serverAuth
subjectAltName = @alt_names

[alt_names]
DNS.1=p.cohenc.fr
DNS.2=p.cohenc
DNS.3=harbor01
EOF

openssl x509 -req -sha512 -days 3650 \
    -extfile v3.ext \
    -CA ca.crt -CAkey ca.key -CAcreateserial \
    -in harbor01.p.cohenc.fr.csr \
    -out harbor01.p.cohenc.fr.crt


[root@harbor01 ssl]# mkdir /apps/harbor/ssl
[root@harbor01 ssl]# cp ca.crt harbor01.p.cohenc.fr.crt harbor01.p.cohenc.fr.key /apps/harbor/ssl/


openssl x509 -inform PEM -in harbor01.p.cohenc.fr.crt -out harbor01.p.cohenc.fr.cert


[root@harbor01 ssl]# mkdir /etc/containers/certs.d/harbor01.p.cohenc.fr/
[root@harbor01 ssl]# cp ca.crt harbor01.p.cohenc.fr.cert harbor01.p.cohenc.fr.key /etc/containers/certs.d/harbor01.p.cohenc.fr/
[root@harbor01 ssl]# 


[root@harbor01 harbor]# vi install.sh 
[root@harbor01 harbor]# ./install.sh --with-trivy --with-chartmuseum  --with-notary

[Step 0]: checking if podman is installed ...
./install.sh: line 55: check_podman: command not found
[root@harbor01 harbor]# vi common.sh 
[root@harbor01 harbor]# ./install.sh --with-trivy --with-chartmuseum  --with-notary

[Step 0]: checking if podman is installed ...

Note: podman version: 3.2.3
✖ Need to upgrade podman package to 17.06.0+.
[root@harbor01 harbor]# vi common.sh 
[root@harbor01 harbor]# vi install.sh 
[root@harbor01 harbor]# ./install.sh --with-trivy --with-chartmuseum  --with-notary

[Step 0]: checking if podman is installed ...

[Step 1]: checking podman-compose is installed ...
✖ Need to install podman-compose(1.18.0+) by yourself first and run this script again.
[root@harbor01 harbor]# vi install.sh 
[root@harbor01 harbor]# ./install.sh --with-trivy --with-chartmuseum  --with-notary

[Step 0]: checking if podman is installed ...

[Step 1]: checking podman-compose is installed ...

[Step 2]: loading Harbor images ...
Getting image source signatures
Copying blob 9a44ae952baa done  
Copying blob 17517bb678cd done  
Copying blob 41648b8ffd20 done  
Copying blob 7be8271fd6c7 done  
Copying blob c179ae9f4bb4 done  
Copying config 719fd82565 done  
Writing manifest to image destination
Storing signatures
Getting image source signatures
Copying blob 41648b8ffd20 skipped: already exists  
Copying blob b0b3b7027bf9 done  
Copying blob b3fe5603c553 done  
Copying blob 5aabddd05f7d done  
Copying blob c9199a5d2e42 done  
Copying blob 227ae5e03e36 done  
Copying blob 56dacaf676bf done  
Copying config 7e29ff33ec done  
Writing manifest to image destination
Storing signatures
Getting image source signatures
Copying blob 993405872011 done  
Copying blob f670a46c0b96 done  
Copying blob ae3b7f58d662 done  
Copying blob ab617bd5330b done  
Copying blob 9476ba967537 done  
Copying blob 41648b8ffd20 skipped: already exists  
Copying blob 675afd4bd758 done  
Copying config a285847f85 done  
Writing manifest to image destination
Storing signatures
Getting image source signatures
Copying blob 41648b8ffd20 skipped: already exists  
Copying blob 891c37c24656 done  
Copying blob 48fc1e32997f done  
Copying blob fb11e66e79e5 done  
Copying config 4a15c5622f done  
Writing manifest to image destination
Storing signatures
Getting image source signatures
Copying blob 41648b8ffd20 skipped: already exists  
Copying blob 2c7f77f6876c done  
Copying blob 56498e347596 done  
Copying blob ed74a6a7b440 done  
Copying blob d01f3ed208d8 done  
Copying blob c32a505aa2f0 done  
Copying blob b2f51c8b45a8 done  
Copying blob 2e197003cccc done  
Copying config 40a54594fe done  
Writing manifest to image destination
Storing signatures
Getting image source signatures
Copying blob 1d75c3374e9d done  
Copying blob 41648b8ffd20 skipped: already exists  
Copying blob 7a40b6380552 done  
Copying blob 9ecfab6fa075 done  
Copying blob c6e15e4ae5fb done  
Copying config 4a0d49a4ec done  
Writing manifest to image destination
Storing signatures
Getting image source signatures
Copying blob 34b6ccfac5c2 done  
Copying blob a28c2a8375ca done  
Copying blob 41648b8ffd20 skipped: already exists  
Copying blob 8437731789fe done  
Copying blob 31642a03170c done  
Copying blob 7f18da92ac8b done  
Copying config 972ce19b18 done  
Writing manifest to image destination
Storing signatures
Getting image source signatures
Copying blob 1e3e5d3c79f5 done  
Copying blob 41648b8ffd20 skipped: already exists  
Copying blob 58cde91723f8 done  
Copying blob c0188fb7ac5e done  
Copying blob bf4235a4524f done  
Copying blob 6508007064f0 done  
Copying config 3aba4510af done  
Writing manifest to image destination
Storing signatures
Getting image source signatures
Copying blob 41648b8ffd20 skipped: already exists  
Copying blob 8d8901f3d965 done  
Copying blob 2f986b213a04 done  
Copying blob 6ea65b302583 done  
Copying blob 1efde676daf0 done  
Copying blob 7bae6a694788 done  
Copying blob 5d840160fb5d done  
Copying blob 26cb8c7aea8d done  
Copying blob 443113e62c34 done  
Copying blob 3e1a33180139 done  
Copying config f05acc3947 done  
Writing manifest to image destination
Storing signatures
Getting image source signatures
Copying blob 41648b8ffd20 skipped: already exists  
Copying blob 568aa0938e2b done  
Copying config 3b3ede1db4 done  
Writing manifest to image destination
Storing signatures
Getting image source signatures
Copying blob 41648b8ffd20 skipped: already exists  
Copying blob 9615e6a413fc done  
Copying blob f931e142cd2a done  
Copying blob be5733782dee done  
Copying blob 1bd011bea638 done  
Copying blob 46add47c68f7 done  
Copying config d6e174ae0a done  
Writing manifest to image destination
Storing signatures
Getting image source signatures
Copying blob 41648b8ffd20 skipped: already exists  
Copying blob 7aa7ae559e6f done  
Copying blob 6280cae51b87 done  
Copying blob 8aa07e284ff4 done  
Copying blob 12fba5dd3cff done  
Copying blob a931ad0ebeec done  
Copying blob bf3312aad87c done  
Copying blob 26533fac7c1e done  
Copying blob f446e0ed5972 done  
Copying blob 7ba282a434e9 done  
Copying blob 5e2cdabb008b done  
Copying blob e8d195e5c8a9 done  
Copying blob bdeafdbba632 done  
Copying config b16a9c81ef done  
Writing manifest to image destination
Storing signatures
Getting image source signatures
Copying blob 41648b8ffd20 skipped: already exists  
Copying blob 27ae7e20b29c done  
Copying blob fe71feca4246 done  
Copying blob 94b3f2d8cdd7 done  
Copying blob 46ff71a6049d done  
Copying blob efbb0d26fe83 done  
Copying blob 1a981ee576a1 done  
Copying config 91e7980049 done  
Writing manifest to image destination
Storing signatures
Getting image source signatures
Copying blob 41648b8ffd20 skipped: already exists  
Copying blob ecc73b87b065 done  
Copying blob 3ad82d257ca6 done  
Copying blob 8d918fd98283 done  
Copying blob 93dd6303ff3b done  
Copying blob 28412d166d6b done  
Copying blob 452f20807663 done  
Copying config 87a2dbfd12 done  
Writing manifest to image destination
Storing signatures
Getting image source signatures
Copying blob 96e730f54bab done  
Copying blob 0c8d86f5f206 done  
Copying blob 8b9538516c74 done  
Copying blob b776fbc32b13 done  
Copying blob 41648b8ffd20 skipped: already exists  
Copying blob 48b6940bb86c done  
Copying blob 105aaabe98d9 done  
Copying blob 134aa3315fc8 done  
Copying config 4ce629d59c done  
Writing manifest to image destination
Storing signatures
Loaded image(s): localhost/goharbor/harbor-exporter:v2.3.1,localhost/goharbor/notary-signer-photon:v2.3.1,localhost/goharbor/trivy-adapter-photon:v2.3.1,localhost/goharbor/harbor-portal:v2.3.1,localhost/goharbor/harbor-log:v2.3.1,localhost/goharbor/redis-photon:v2.3.1,localhost/goharbor/registry-photon:v2.3.1,localhost/goharbor/chartmuseum-photon:v2.3.1,localhost/goharbor/harbor-core:v2.3.1,localhost/goharbor/nginx-photon:v2.3.1,localhost/goharbor/harbor-jobservice:v2.3.1,localhost/goharbor/harbor-db:v2.3.1,localhost/goharbor/harbor-registryctl:v2.3.1,localhost/goharbor/notary-server-photon:v2.3.1,localhost/goharbor/prepare:v2.3.1


[Step 3]: preparing environment ...

[Step 4]: preparing harbor configs ...
prepare base dir is set to /apps/harbor/harbor
./prepare: line 54: docker: command not found
[root@harbor01 harbor]# 


Press ENTER or type command to continue
[root@harbor01 harbor]# ./prepare --with-notary --with-trivy --with-chartmuseum
prepare base dir is set to /apps/harbor/harbor
/apps/harbor/harbor
/data
Clearing the configuration file: /config/portal/nginx.conf
Clearing the configuration file: /config/log/logrotate.conf
Clearing the configuration file: /config/log/rsyslog_docker.conf
Generated configuration file: /config/portal/nginx.conf
Generated configuration file: /config/log/logrotate.conf
Generated configuration file: /config/log/rsyslog_docker.conf
Generated configuration file: /config/nginx/nginx.conf
Generated configuration file: /config/core/env
Generated configuration file: /config/core/app.conf
Generated configuration file: /config/registry/config.yml
Generated configuration file: /config/registryctl/env
Generated configuration file: /config/registryctl/config.yml
Generated configuration file: /config/db/env
Generated configuration file: /config/jobservice/env
Generated configuration file: /config/jobservice/config.yml
Generated and saved secret to file: /data/secret/keys/secretkey
Successfully called func: create_root_cert
Successfully called func: create_root_cert
Successfully called func: create_cert
Copying certs for notary signer
Copying nginx configuration file for notary
Generated configuration file: /config/nginx/conf.d/notary.upstream.conf
Generated configuration file: /config/nginx/conf.d/notary.server.conf
Generated configuration file: /config/notary/server-config.postgres.json
Generated configuration file: /config/notary/server_env
Generated and saved secret to file: /data/secret/keys/defaultalias
Generated configuration file: /config/notary/signer_env
Generated configuration file: /config/notary/signer-config.postgres.json
Generated configuration file: /config/trivy-adapter/env
Generated configuration file: /config/chartserver/env
Generated configuration file: /compose_location/docker-compose.yml
Clean up the input dir

