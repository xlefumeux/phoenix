# Cilium version: 1.10-2
## customise values.yaml 
- private-registry
- replicas
- resources
- ...
## install 
```sh
helm upgrade --install  cilium -f values.yaml --namespace kube-system ./cilium/
```