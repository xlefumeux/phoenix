# nginx controller
## customise values.yaml 
- private-registry
- replicas
- resources
- ...
## install 
```sh
helm upgrade --install nginx-ingress --namespace nginx-ingress ./ingress-controller
```

## validation 
ne pas oublier de customiser les fichiers (private registry notemment)
```sh
kubectl apply -f validation/
```
