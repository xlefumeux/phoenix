# Deploying the DNS Cluster Add-on

In this lab you will deploy the [DNS add-on](https://kubernetes.io/docs/concepts/services-networking/dns-pod-service/) which provides DNS based service discovery to applications running inside the Kubernetes cluster.


## The private registry
Before  installing our 1st pod we need to prepare the secret  in order to connect to the private registry 
```sh
kubectl create secret docker-registry regcred --docker-server=<your-registry-server> --docker-username=<your-name> --docker-password=<your-pword> --docker-email=<your-email>
```
## The DNS Cluster Add-on

Deploy the `kube-dns` cluster add-on:

```sh
 k create secret docker-registry nexus --docker-server=registry01.p.cohenc.fr:10579 --docker-username=admin --docker-password= --docker-email=admin@cohenc.fr -n kube-system

kubectl apply -f ../deployments/core-dns.yaml
```

because the cluster is airgapped  some modifications needs to be done on the deployment
replace image
```yaml
image: <custom registry>/coredns/coredns:1.7.0
dnsPolicy: Default
      imagePullSecrets:
        - name: <secret name>
```

> output

```
service "kube-dns" created
serviceaccount "kube-dns" created
configmap "kube-dns" created
deployment.extensions "kube-dns" created
```

List the pods created by the `kube-dns` deployment:

```
kubectl get pods -l k8s-app=kube-dns -n kube-system
```

> output

```
NAME                        READY     STATUS    RESTARTS   AGE
kube-dns-3097350089-gq015   3/3       Running   0          20s
```

## Verification

Create a `dnsutils` pod

```sh
# pay attention to the secret in order to pull from private registry
kubectl run busybox --image=<my private registry>/busybox:1.28 --restart=Never -- sleep 3600
```

Verify that the pod is running:

```sh
kubectl get pod busybox
```

Output:
```
NAME       READY     STATUS    RESTARTS   AGE
busybox   1/1       Running   0          45s
```

Execute a DNS lookup for the `kubernetes` service inside the `dnsutils` pod:

```
kubectl exec -it busybox -- nslookup kubernetes
```

> output

```
Server:    10.32.0.10
Address 1: 10.32.0.10 kube-dns.kube-system.svc.cluster.local

Name:      kubernetes
Address 1: 10.32.0.1 kubernetes.default.svc.cluster.local
```

Next: [Smoke Test](13-smoke-test.md)
