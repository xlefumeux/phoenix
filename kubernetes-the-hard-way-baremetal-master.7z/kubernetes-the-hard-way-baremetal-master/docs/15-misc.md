## debug
```sh
# CURL 
echo "
apiVersion: v1
kind: Pod
metadata:
  name: testcurl
spec:
  containers:
  - name: curl
    image: registry01.p.cohenc.fr/nexus/curlimages/curl 
    command: [ \"sleep\", \"600\" ]
  nodeSelector:
    kubernetes.io/hostname: kthw-crio-03"| kubectl apply -f -
    
# CURL 
echo "
apiVersion: v1
kind: Pod
metadata:
  name: testcurl
spec:
  containers:
  - name: curl
    image: registry01.p.cohenc.fr/nexus/curlimages/curl 
    command: [ \"sleep\", \"600\" ]"| kubectl apply -f -

# DNS resolution
echo "apiVersion: v1
kind: Pod
metadata:
  name: dnsutils
spec:
  containers:
  - name: dnsutils
    image: registry01.p.cohenc.fr/nexus/kubernetes-e2e-test-images/dnsutils:1.3
    command:
      - sleep
      - \"3600\"
    imagePullPolicy: IfNotPresent
  restartPolicy: Always"| kubectl apply -f -

echo "apiVersion: v1
kind: Pod
metadata:
  name: dnsutils-02
spec:
  containers:
  - name: dnsutils
    image: registry01.p.cohenc.fr/nexus/kubernetes-e2e-test-images/dnsutils:1.3
    command:
      - sleep
      - \"3600\"
    imagePullPolicy: IfNotPresent
  restartPolicy: Always
  nodeSelector:
    kubernetes.io/hostname: kthw-crio-02"| kubectl apply -f -
```

## errors
### Erreur DNS
from a POD:
dig kubernetes.default
;; reply from unexpected source: 10.200.11.43#53, expected 10.32.0.10#53
;; reply from unexpected source: 10.200.11.43#53, expected 10.32.0.10#53

netfilter module is not loaded 
to enable it : 
```sh
echo 'br_netfilter' > /etc/modules-load.d/br_netfilter.conf && systemctl restart systemd-modules-load.service

```
### Erreur cgroup
Failed to get system container stats for "/system.slice/kubelet.service": failed to get cgroup stats for "/system.slice/kubelet.service": failed to get container info for "/system.slice/kubelet.service": unknown container "/system.slice/kubelet.service"
fixed by adding more properties into systemd

```sh
cat kubelet.service.d/11-cgroups.conf 
[Service]
CPUAccounting=true
MemoryAccounting=true
```
### Erreur Webhooks
error validation webhook (ex certmanager mais  pareil avec ingress) 
Error from server (InternalError): error when creating "test-resources.yaml": Internal error occurred: failed calling webhook "webhook.cert-manager.io": Post "https://cert-manager-webhook.cert-manager.svc:443/mutate?timeout=10s": context deadline exceeded

ajout des parametre dans le service du kube-apiserver (ajout de ValidationAdmissionWebhook) [link](https://github.com/jetstack/cert-manager/issues/2640)
--enable-admission-plugins=NamespaceLifecycle,NodeRestriction,LimitRanger,ServiceAccount,DefaultStorageClass,DefaultTolerationSeconds,MutatingAdmissionWebhook,ValidatingAdmissionWebhook,Priority,ResourceQuota \\