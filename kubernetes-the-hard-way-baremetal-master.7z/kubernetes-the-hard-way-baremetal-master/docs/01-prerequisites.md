# Prerequisites

## Bare metal infrastucture

This tutorial suppose that you have  full access to virtual machines or baremetal.


## Running Commands in Parallel with tmux

[tmux](https://github.com/tmux/tmux/wiki) can be used to run commands on multiple compute instances at the same time. Labs in this tutorial may require running the same commands across multiple compute instances, in those cases consider using tmux and splitting a window into multiple panes with `synchronize-panes` enabled to speed up the provisioning process.

> The use of tmux is optional and not required to complete this tutorial.

![tmux screenshot](images/tmux-screenshot.png)

> Enable `synchronize-panes`: `ctrl+b` then `shift :`. Then type `set synchronize-panes on` at the prompt. To disable synchronization: `set synchronize-panes off`.

Next: [Installing the Client Tools](02-client-tools.md)


## Config HAProxy

```bash
[ccohen@proxy01 haproxy]$ cat /etc/haproxy/haproxy.cfg
global
	log /dev/log	local0
	log /dev/log	local1 notice
#	chroot /var/lib/haproxy
	stats socket /var/run/haproxy/admin.sock mode 660 level admin expose-fd listeners
	stats timeout 30s
#	user haproxy
#	group haproxy
	daemon

	# Default SSL material locations
	ca-base /etc/ssl/certs
	crt-base /etc/ssl/private

	# See: https://ssl-config.mozilla.org/#server=haproxy&server-version=2.0.3&config=intermediate
        ssl-default-bind-ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:DHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384
        ssl-default-bind-ciphersuites TLS_AES_128_GCM_SHA256:TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256
        ssl-default-bind-options ssl-min-ver TLSv1.2 no-tls-tickets

defaults
	log	global
	mode	http
	option	httplog
	option	dontlognull
    timeout connect 30000
    timeout client  300000
    timeout server  300000
	errorfile 400 /etc/haproxy/errors/400.http
	errorfile 403 /etc/haproxy/errors/403.http
	errorfile 408 /etc/haproxy/errors/408.http
	errorfile 500 /etc/haproxy/errors/500.http
	errorfile 502 /etc/haproxy/errors/502.http
	errorfile 503 /etc/haproxy/errors/503.http
	errorfile 504 /etc/haproxy/errors/504.http

listen stats
  bind 0.0.0.0:9000

frontend k8s-api
  bind 192.168.10.1:443
  mode tcp
  option tcplog
  default_backend k8s-api

frontend k8s-ingress-http
  bind 192.168.10.2:80
  mode tcp
  option tcplog
  default_backend k8s-ingress-http

frontend k8s-ingress-https
  bind 192.168.10.2:443
  mode tcp
  option tcplog
  default_backend k8s-ingress-https

backend k8s-ingress-http
  mode tcp
  option tcp-check
  balance roundrobin
  default-server inter 10s downinter 5s rise 2 fall 2 slowstart 60s maxconn 250 maxqueue 256 weight 100
  server kthw-crio-01 192.168.40.4:30080 check
  server kthw-crio-02 192.168.40.5:30080 check
  server kthw-crio-03 192.168.40.6:30080 check

backend k8s-ingress-https
  mode tcp
  option tcp-check
  balance roundrobin
  default-server inter 10s downinter 5s rise 2 fall 2 slowstart 60s maxconn 250 maxqueue 256 weight 100
  server kthw-crio-01 192.168.40.4:30443 check
  server kthw-crio-02 192.168.40.5:30443 check
  server kthw-crio-03 192.168.40.6:30443 check

backend k8s-api
  mode tcp
  option tcp-check
  balance roundrobin
  default-server inter 10s downinter 5s rise 2 fall 2 slowstart 60s maxconn 250 maxqueue 256 weight 100
  server kthw-master-01 192.168.40.7:6443 check
  server kthw-master-02 192.168.40.8:6443 check
  server kthw-master-03 192.168.40.9:6443 check

```
