# Provisioning Compute Resources

[Guide](https://github.com/kelseyhightower/kubernetes-the-hard-way/blob/master/docs/03-compute-resources.md)

## Networking

### VPC

```sh
VPC_ID=$(aws ec2 create-vpc --cidr-block 10.1.0.0/16 --output text --query 'Vpc.VpcId')
aws ec2 create-tags --resources ${VPC_ID} --tags Key=Name,Value=ccn-vpc
aws ec2 create-tags --resources ${VPC_ID} --tags Key=Owner,Value=clement.cohen@ext.soprasteria.com
aws ec2 modify-vpc-attribute --vpc-id ${VPC_ID} --enable-dns-support '{"Value": true}'
aws ec2 modify-vpc-attribute --vpc-id ${VPC_ID} --enable-dns-hostnames '{"Value": true}'
```

### Subnet

```sh
SUBNET_K8S=$(aws ec2 create-subnet \
  --vpc-id ${VPC_ID} \
  --cidr-block 10.1.1.0/24 \
  --output text --query 'Subnet.SubnetId')
aws ec2 create-tags --resources ${SUBNET_K8S} --tags Key=Name,Value=ccn-k8s
aws ec2 create-tags --resources ${SUBNET_K8S} --tags Key=Owner,Value=clement.cohen@ext.soprasteria.com
```

### Route Tables

```sh
ROUTE_TABLE_K8S=$(aws ec2 create-route-table --vpc-id ${VPC_ID} --output text --query 'RouteTable.RouteTableId')
aws ec2 create-tags --resources ${ROUTE_TABLE_K8S} --tags Key=Name,Value=ccn-localonly
aws ec2 create-tags --resources ${ROUTE_TABLE_K8S} --tags Key=Owner,Value=clement.cohen@ext.soprasteria.com

aws ec2 associate-route-table --route-table-id ${ROUTE_TABLE_K8S} --subnet-id ${SUBNET_K8S}
# aws ec2 create-route --route-table-id ${ROUTE_TABLE_ID} --destination-cidr-block 0.0.0.0/0 --gateway-id ${INTERNET_GATEWAY_ID}
```

### Security Groups (aka Firewall Rules)

```sh
SECURITY_GROUP_K8S=$(aws ec2 create-security-group \
  --group-name ccn-k8s \
  --description "Kubernetes security group" \
  --vpc-id ${VPC_ID} \
  --output text --query 'GroupId')
aws ec2 create-tags --resources ${SECURITY_GROUP_K8S} --tags Key=Name,Value=ccn-k8s
aws ec2 create-tags --resources ${SECURITY_GROUP_K8S} --tags Key=Owner,Value=clement.cohen@ext.soprasteria.com
aws ec2 authorize-security-group-ingress --group-id ${SECURITY_GROUP_K8S} --protocol all --cidr 10.1.0.0/16

# Création security group pour la registry docker
SECURITY_GROUP_REGISTRY=$(aws ec2 create-security-group \
  --group-name ccn-registry \
  --description "Docker Registry security group" \
  --vpc-id ${VPC_ID} \
  --output text --query 'GroupId')
aws ec2 create-tags --resources ${SECURITY_GROUP_K8S} --tags Key=Name,Value=ccn-registry
aws ec2 create-tags --resources ${SECURITY_GROUP_K8S} --tags Key=Owner,Value=clement.cohen@ext.soprasteria.com
aws ec2 authorize-security-group-ingress --group-id ${SECURITY_GROUP_K8S} --protocol all --cidr 10.1.0.0/16
```

## Compute Instances

### Instance Image

```sh
IMAGE_ID=$(aws ec2 describe-images --owners 099720109477 \
  --filters \
  'Name=root-device-type,Values=ebs' \
  'Name=architecture,Values=x86_64' \
  'Name=name,Values=ubuntu/images/hvm-ssd/ubuntu-focal-20.04-amd64-server-*' \
  | jq -r '.Images|sort_by(.Name)[-1]|.ImageId')
```

### SSH Key Pair

```sh
aws ec2 create-key-pair --key-name ccn-aws --output text --query 'KeyMaterial' > kubernetes.id_rsa
chmod 600 kubernetes.id_rsa
```

### Kubernetes Controllers

Using `t3.micro` instances

```sh
for i in 0 1 2; do
  instance_id=$(aws ec2 run-instances \
    --image-id ${IMAGE_ID} \
    --count 1 \
    --key-name ccn-aws \
    --security-group-ids ${SECURITY_GROUP_K8S} \
    --instance-type t3.micro \
    --private-ip-address 10.1.1.1${i} \
    --user-data "name=controller-${i}" \
    --subnet-id ${SUBNET_K8S} \
    --block-device-mappings='{"DeviceName": "/dev/sda1", "Ebs": { "VolumeSize": 50 }, "NoDevice": "" }' \
    --output text --query 'Instances[].InstanceId')
  aws ec2 modify-instance-attribute --instance-id ${instance_id} --no-source-dest-check
  aws ec2 create-tags --resources ${instance_id} --tags "Key=Name,Value=controller-${i}"
  aws ec2 create-tags --resources ${instance_id} --tags "Key=Owner,Value=clement.cohen@ext.soprasteria.com"
  aws ec2 create-tags --resources ${instance_id} --tags="Key=scheduler:ec2-startstop,Value=none\;1930"
  echo "controller-${i} created "
done
```

### Kubernetes Workers

```sh
for i in 0 1 2; do
  instance_id=$(aws ec2 run-instances \
    --image-id ${IMAGE_ID} \
    --count 1 \
    --key-name ccn-aws \
    --security-group-ids ${SECURITY_GROUP_K8S} \
    --instance-type t3.micro \
    --private-ip-address 10.1.1.3${i} \
    --user-data "name=worker-${i}|pod-cidr=10.200.${i}.0/24" \
    --subnet-id ${SUBNET_K8S} \
    --block-device-mappings='{"DeviceName": "/dev/sda1", "Ebs": { "VolumeSize": 50 }, "NoDevice": "" }' \
    --output text --query 'Instances[].InstanceId')
  aws ec2 modify-instance-attribute --instance-id ${instance_id} --no-source-dest-check
  aws ec2 create-tags --resources ${instance_id} --tags "Key=Name,Value=worker-${i}"
  aws ec2 create-tags --resources ${instance_id} --tags "Key=Owner,Value=clement.cohen@ext.soprasteria.com"
  aws ec2 create-tags --resources ${instance_id} --tags="Key=scheduler:ec2-startstop,Value=none\;1930"
  echo "worker-${i} created"
done
```

### Docker Registry

```sh

instance_id=$(aws ec2 run-instances \
  --image-id ${IMAGE_ID} \
  --count 1 \
  --key-name ccn-aws \
  --security-group-ids ${SECURITY_GROUP_REGISTRY} \
  --instance-type t3.micro \
  --user-data "name=registry" \
  --subnet-id ${SUBNET_SERVITUDE} \
  --block-device-mappings='{"DeviceName": "/dev/sda1", "Ebs": { "VolumeSize": 50 }, "NoDevice": "" }' \
  --output text --query 'Instances[].InstanceId')
aws ec2 modify-instance-attribute --instance-id ${instance_id} --no-source-dest-check
aws ec2 create-tags --resources ${instance_id} --tags "Key=Name,Value=registry"
aws ec2 create-tags --resources ${instance_id} --tags "Key=Owner,Value=clement.cohen@ext.soprasteria.com"
aws ec2 create-tags --resources ${instance_id} --tags="Key=scheduler:ec2-startstop,Value=none\;1930"

```

### Proxy Setup 
ssh into each machine to  setup the outgoing PROXY
```sh
echo "PROXY_URL=\"http://10.1.0.12:3128/\"
NOPROXY=\"127.0.0.1,localhost,.kthw.sandbox\"

export http_proxy=\"\$PROXY_URL\"
export https_proxy=\"\$PROXY_URL\"
export ftp_proxy=\"\$PROXY_URL\"
export no_proxy=\"\$NOPROXY\"

# For curl
export HTTP_PROXY=\"\$PROXY_URL\"
export HTTPS_PROXY=\"\$PROXY_URL\"
export FTP_PROXY=\"\$PROXY_URL\"
export NO_PROXY=\"\$NOPROXY\"" | sudo tee /etc/profile.d/proxy.sh

echo "Acquire::http::proxy \"http://10.1.0.12:3128/\";" | sudo tee /etc/apt/apt.conf.d/01Proxy
```

Next: [Certificate Authority](04-certificate-authority.md)
