# Activation of the optional and extras repositories

[root@dm1alx092 ~]# subscription-manager repos --enable=rhel-7-server-optional-rpms
Repository 'rhel-7-server-optional-rpms' is enabled for this system.
[root@dm1alx092 ~]# subscription-manager repos --enable=rhel-7-server-extras-rpms
Repository 'rhel-7-server-extras-rpms' is enabled for this system.
[root@dm1alx092 cri-o-release-1.20]# subscription-manager repos --enable=RET-INF_EPEL_EPEL_7Server
Repository 'RET-INF_EPEL_EPEL_7Server' is enabled for this system.

# Preparation of the compilation of CRI-of

[root@dm1alx092 ~]# yum install -y \
containers-common \
device-mapper-devel \
git \
glib2-devel \
glibc-devel \
glibc-statis \
go \
gpgme-devel \
libassuan-devel \
libgpg-error-devel \
libseccomp-devel \
libselinux-devel \
pkgconfig \
make

# Get RUNC source (from dm1alx090, under /applis/m1ad/r2prepo, version 1.0.0)

[root@dm1alx091 runc-1.0.0]# make -j4
[root@dm1alx091 runc-1.0.0]# make install
[root@dm1alx091 runc-1.0.0]# runc --version
runc version 1.0.0
spec: 1.0.2-dev
go: go1.16.5
libseccomp: 2.3.1

# Get CRI-O source (from dm1alx090, under ~/compile)

# on dm1alx090
[root@dm1alx092 ~]# mkdir ~/compile && cd ~/compile
[root@dm1alx092 compile]# git clone https://github.com/cri-o/cri-o
# or get zip file of cri-o v1.20.3 from github in Citrix VM and scp file to target

# on dm1alx092

[root@dm1alx092 compile]# unzip cri-o-release-1.20.zip
[root@dm1alx092 compile]# cd cri-o-release-1.20/
[root@dm1alx092 cri-o-release-1.20]# make -j4
[root@dm1alx092 cri-o-release-1.20]# make install
[root@dm1alx092 cri-o-release-1.20]# crio version

# Get CONMON source (from dm1alx090, under ~/compile)

# on dm1alx090
[root@dm1alx092 compile]# git clone https://github.com/containers/conmon
# or get zip file of conmon v2.0.29 from github in Citrix VM and scp file to target

[root@dm1alx092 compile]# unzip conmon-2.0.29.zip
[root@dm1alx092 compile]# cd conmon-2.0.29/
[root@dm1alx092 common-2.0.29]# make -j4
[root@dm1alx092 common-2.0.29]# make install
[root@dm1alx092 common-2.0.29]# conmon --version

# Configure CNI

[root@dm1alx092 cri-o-release-1.20]# mkdir -p /etc/cni/net.d
[root@dm1alx092 cri-o-release-1.20]# cp contrib/cni/11-crio-ipv4-bridge.conf /etc/cni/net.d/

# on dm1alx090
[root@dm1alx092 compile]# git clone https://github.com/containernetworking/plugins
# or get zip file of plugins v0.8.7 from github in Citrix VM and scp file to target

[root@dm1alx092 compile]# unzip plugins-0.8.7.zip
[root@dm1alx092 compile]# cd plugins-0.8.7/
[root@dm1alx092 plugins-0.8.7]# ./build_linux.sh
[root@dm1alx092 plugins-0.8.7]# mkdir -p /opt/cni/bin
[root@dm1alx092 plugins-0.8.7]# cp bin/* /opt/cni/bin/

# Configure CRI-O

[root@dm1alx092 cri-o-release-1.20]# make install.config
[root@dm1alx092 cri-o-release-1.20]# cat << EOF| sudo tee /etc/crio/crio.conf.d/01-runtime.conf
[crio.runtime]
selinux = false
log_level = "debug"
seccomp_profile = "/usr/share/containers/seccomp.json"
EOF

[root@dm1alx092 cri-o-release-1.20]# cat << EOF| sudo tee /etc/crio/crio.conf.d/02-registry.conf
[crio.image]
pause_image = "dm1alx090.dns21.socgen/k8s/pause:3.2"
global_auth_file = "/etc/containers/registry_auth.json"
EOF

[root@dm1alx092 cri-o-release-1.20]# cat << EOF| sudo tee /etc/containers/registries.d/private.yaml
registries:
  search:
    - dm1alx090.dns21.socgen/k8s
  insecure:
    registries: []
  block:
    registries: []
EOF

[root@dm1alx092 cri-o-release-1.20]# cat << EOF| sudo tee /etc/containers/registry_auth.json
{
    "auths": {
        "dm1alx090.dns21.socgen": {
            "auth": "YWRtaW46SGFyYm9yMTIzNDU="
        }
    }
}
EOF

# Copy registry certificates to /etc/containers/certs.d/dm1alx090.dns21.socgen/

# Configure systemd for CRI-O

[root@dm1alx092 cri-o-release-1.20]# make install.systemd

[root@dm1alx092 cri-o-release-1.20]# systemctl daemon-reload
[root@dm1alx092 cri-o-release-1.20]# systemctl enable crio
[root@dm1alx092 cri-o-release-1.20]# systemctl start crio
[root@dm1alx092 cri-o-release-1.20]# systemctl status crio
● crio.service - Container Runtime Interface for OCI (CRI-O)
   Loaded: loaded (/usr/local/lib/systemd/system/crio.service; enabled; vendor preset: disabled)
   Active: active (running) since Fri 2021-09-03 10:35:54 CEST; 1 weeks 4 days ago
     Docs: https://github.com/cri-o/cri-o
 Main PID: 1380 (crio)
   CGroup: /system.slice/crio.service
           └─1380 /usr/local/bin/crio

# Validate CRI-O installation

[root@dm1alx092 crictl-v1.20.3]# tar xvfz crictl-v1.20.0-linux-amd64.tar.gz -C /usr/local/bin/
[root@dm1alx092 crictl-v1.20.3]# crictl version
Version:  0.1.0
RuntimeName:  cri-o
RuntimeVersion:  1.20.5
RuntimeApiVersion:  v1alpha1

# Backup default policy.json
[root@dm1alx092 cri-o-release-1.20]# mv /etc/containers/policy.json /etc/containers/policy_json.orig
[root@dm1alx092 cri-o-release-1.20]# cp test/policy.json /etc/containers/policy.json

# Verify pod and container are not already created and running
crictl pods
crictl ps

# Cleanup in case already there
crictl stop $CONTAINER_ID
crictl rm $CONTAINER_ID
crictl stopp $POD_ID
crictl rmp $POD_ID

# Edit image reference in test/testdata/container_redis.json
...
"image": {
                "image": "dm1alx090.dns21.socgen/k8s/redis:alpine"
        },
...

[root@dm1alx092 cri-o-release-1.20]# POD_ID=$(sudo crictl runp test/testdata/sandbox_config.json)
[root@dm1alx092 cri-o-release-1.20]# echo $POD_ID
390a22a1782cf87bd858f521b6fb14e805b523b1b53fc8b95c9854b97081be33
[root@dm1alx092 cri-o-release-1.20]# crictl inspectp --output table $POD_ID | more
ID: 390a22a1782cf87bd858f521b6fb14e805b523b1b53fc8b95c9854b97081be33
Name: podsandbox1
UID: redhat-test-crio
Namespace: redhat.test.crio
Attempt: 1
Status: SANDBOX_READY
Created: 2021-09-14 15:35:58.895351476 +0200 CEST
IP Addresses: 10.85.0.3
Labels:
        group -> test
        io.kubernetes.container.name -> POD
Annotations:
        owner -> hmeng
        security.alpha.kubernetes.io/seccomp/pod -> unconfined
Info: map[info:{"image":"dm1alx090.dns21.socgen/k8s/pause:3.2","pid":25870,"runtimeSpec":{"ociVersion":"1.0.2-dev","process":{"user":{"uid":0,"gid":0},"args":["/pause"],"env":["PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin","TERM=xterm"],"cwd":"/","capabilities":{"bounding":["CAP_CHOWN","CAP_DAC_OVERRIDE","CAP_FSETID","CAP_FOWNER","CAP_SETGID","CAP_SETUID","CAP_SETPCAP","CAP_NET_BIND_SERVICE","CAP_KILL"],"effective":["CAP_CHOWN","CAP_DAC_OVERRIDE","CAP_FSETID","CAP_FOWNER","CAP_SETGID","CAP_SETUID","CAP_SETPCAP","CAP_NET_BIND_SERVICE","CAP_KILL"],"inheritable":["CAP_CHOWN","CAP_DAC_OVERRIDE","CAP_FSETID","CAP_FOWNER","CAP_SETGID","CAP_SETUID","CAP_SETPCAP","CAP_NET_BIND_SERVICE","CAP_KILL"],"permitted":["CAP_CHOWN","CAP_DAC_OVERRIDE","CAP_FSETID","CAP_FOWNER","CAP_SETGID","CAP_SETUID","CAP_SETPCAP","CAP_NET_BIND_SERVICE","CAP_KILL"]},"oomScoreAdj":-998},"root":{"path":"/var/lib/containers/storage/overlay/de9b2002ae6c83bb74f5a68115ff2737a1bfebd0127e25fb222ec67ed28dd9bc/merged","readonly":true},"hostname":"crictl_host","mounts":[{"destination":"/proc","type":"proc","source":"proc","options":["nosuid","noexec","nodev"]},{"destination":"/dev","type":"tmpfs","source":"tmpfs","options":["nosuid","strictatime","mode=755","size=65536k"]},{"destination":"/dev/pts","type":"devpts","source":"devpts","options":["nosuid","noexec","newinstance","ptmxmode=0666","mode=0620","gid=5"]},{"destination":"/dev/mqueue","type":"mqueue","source":"mqueue","options":["nosuid","noexec","nodev"]},{"destination":"/sys","type":"sysfs","source":"sysfs","options":["nosuid","noexec","nodev","ro"]},{"destination":"/etc/resolv.conf","type":"bind","source":"/var/run/containers/storage/overlay-containers/390a22a1782cf87bd858f521b6fb14e805b523b1b53fc8b95c9854b97081be33/userdata/resolv.conf","options":["ro","bind","nodev","nosuid","noexec"]},{"destination":"/dev/shm","type":"bind","source":"/var/run/containers/storage/overlay-containers/390a22a1782cf87bd858f521b6fb14e805b523b1b53fc8b95c9854b97081be33/userdata/shm","options":["rw","bind"]},{"destination":"/etc/hostname","type":"bind","source":"/var/run/containers/storage/overlay-containers/390a22a1782cf87bd858f521b6fb14e805b523b1b53fc8b95c9854b97081be33/userdata/hostname","options":["ro","bind","nodev","nosuid","noexec"]}],"annotations":{"io.kubernetes.cri-o.ShmPath":"/var/run/containers/storage/overlay-containers/390a22a1782cf87bd858f521b6fb14e805b523b1b53fc8b95c9854b97081be33/userdata/shm","io.kubernetes.cri-o.Name":"k8s_podsandbox1_redhat.test.crio_redhat-test-crio_1","io.kubernetes.cri-o.ContainerID":"390a22a1782cf87bd858f521b6fb14e805b523b1b53fc8b95c9854b97081be33","io.kubernetes.cri-o.KubeName":"podsandbox1","io.kubernetes.cri-o.HostNetwork":"false","org.systemd.property.CollectMode":"'inactive-or-failed'","security.alpha.kubernetes.io/seccomp/pod":"unconfined","io.kubernetes.cri-o.Annotations":"{\"security.alpha.kubernetes.io/seccomp/pod\":\"unconfined\",\"owner\":\"hmeng\"}","io.kubernetes.cri-o.Labels":"{\"group\":\"test\",\"io.kubernetes.container.name\":\"POD\"}","io.kubernetes.cri-o.Image":"dm1alx090.dns21.socgen/k8s/pause:3.2","io.kubernetes.cri-o.ResolvPath":"/var/run/containers/storage/overlay-containers/390a22a1782cf87bd858f521b6fb14e805b523b1b53fc8b95c9854b97081be33/userdata/resolv.conf","io.kubernetes.cri-o.Created":"2021-09-14T15:35:58.895351476+02:00","owner":"hmeng","io.kubernetes.cri-o.CNIResult":"{\"cniVersion\":\"0.4.0\",\"interfaces\":[{\"name\":\"cni0\",\"mac\":\"da:52:c5:a5:d3:bd\"},{\"name\":\"vethdbeb0cff\",\"mac\":\"7a:5f:ad:8c:8c:43\"},{\"name\":\"eth0\",\"mac\":\"7e:68:44:4b:7f:00\",\"sandbox\":\"/var/run/netns/44a10bed-7510-45e4-87e1-5bf83126d5cf\"}],\"ips\":[{\"version\":\"4\",\"interface\":2,\"address\":\"10.85.0.3/16\",\"gateway\":\"10.85.0.1\"}],\"routes\":[{\"dst\":\"0.0.0.0/0\"}],\"dns\":{}}","io.kubernetes.cri-o.HostnamePath":"/var/run/containers/storage/overlay-containers/390a22a1782cf87bd858f521b6fb14e805b523b1b53fc8b95c9854b97081be33/userdata/hostname","io.kubernetes.cri-o.Metadata":"{\"name\":\"podsandbox1\",\"uid\":\"redhat-test-crio\",\"namespace\":\"redhat.test.crio\",\"attempt\":1}","io.kubernetes.cri-o.SeccompProfilePath":"","io.kubernetes.cri-o.IP.0":"10.85.0.3","io.kubernetes.cri-o.PrivilegedRuntime":"false","io.container.manager":"cri-o","group":"test","io.kubernetes.cri-o.MountPoint":"/var/lib/containers/storage/overlay/de9b2002ae6c83bb74f5a68115ff2737a1bfebd0127e25fb222ec67ed28dd9bc/merged","io.kubernetes.cri-o.Namespace":"redhat.test.crio","io.kubernetes.cri-o.HostName":"crictl_host","io.kubernetes.cri-o.CgroupParent":"pod_123-456.slice","io.kubernetes.cri-o.ContainerName":"k8s_POD_podsandbox1_redhat.test.crio_redhat-test-crio_1","io.kubernetes.cri-o.RuntimeHandler":"","io.kubernetes.cri-o.NamespaceOptions":"{\"pid\":1}","io.kubernetes.cri-o.SandboxID":"390a22a1782cf87bd858f521b6fb14e805b523b1b53fc8b95c9854b97081be33","io.kubernetes.cri-o.ContainerType":"sandbox","io.kubernetes.cri-o.PortMappings":"[]","io.kubernetes.container.name":"POD","io.kubernetes.cri-o.LogPath":"/var/log/crio/pods/390a22a1782cf87bd858f521b6fb14e805b523b1b53fc8b95c9854b97081be33/390a22a1782cf87bd858f521b6fb14e805b523b1b53fc8b95c9854b97081be33.log"},"linux":{"resources":{"devices":[{"allow":false,"access":"rwm"}],"cpu":{"shares":2}},"cgroupsPath":"pod_123-456.slice:crio:390a22a1782cf87bd858f521b6fb14e805b523b1b53fc8b95c9854b97081be33","namespaces":[{"type":"pid"},{"type":"network","path":"/var/run/netns/44a10bed-7510-45e4-87e1-5bf83126d5cf"},{"type":"ipc","path":"/var/run/ipcns/44a10bed-7510-45e4-87e1-5bf83126d5cf"},{"type":"uts","path":"/var/run/utsns/44a10bed-7510-45e4-87e1-5bf83126d5cf"},{"type":"mount"}]}}}]

[root@dm1alx092 cri-o-release-1.20]# CONTAINER_ID=$(sudo crictl create $POD_ID test/testdata/container_redis.json test/testdata/sandbox_config.json)
[root@dm1alx092 cri-o-release-1.20]# crictl start $CONTAINER_ID
71c9098a33f1ae8887e25dbddb49142f2e9741267c413e49fdc77261f958cad2
[root@dm1alx092 cri-o-release-1.20]# crictl inspect $CONTAINER_ID
{
  "status": {
    "id": "71c9098a33f1ae8887e25dbddb49142f2e9741267c413e49fdc77261f958cad2",
    "metadata": {
      "attempt": 0,
      "name": "podsandbox1-redis"
    },
    "state": "CONTAINER_RUNNING",
    "createdAt": "2021-09-14T15:48:26.321264896+02:00",
    "startedAt": "2021-09-14T15:49:42.456378132+02:00",
    "finishedAt": "1970-01-01T01:00:00+01:00",
    "exitCode": 0,
    "image": {
      "annotations": {},
      "image": "dm1alx090.dns21.socgen/k8s/redis:alpine"
    },
    "imageRef": "dm1alx090.dns21.socgen/k8s/redis@sha256:aab35d6ec4c49ef5c1674f0582eeb2f6e90ee0fd3010d8a806d8833f36cc0525",
    "reason": "",
    "message": "",
    "labels": {
      "tier": "backend"
    },
    "annotations": {
      "pod": "podsandbox1"
    },
    "mounts": [],
    "logPath": "/var/log/crio/pods/390a22a1782cf87bd858f521b6fb14e805b523b1b53fc8b95c9854b97081be33/71c9098a33f1ae8887e25dbddb49142f2e9741267c413e49fdc77261f958cad2.log"
  },
...

[root@dm1alx092 cri-o-release-1.20]# POD_IP=$(sudo crictl inspectp -output go-template --template '{{.status.network.ip}}' $POD_ID)
[root@dm1alx092 cri-o-release-1.20]# echo $POD_IP
10.85.0.3

[root@dm1alx092 cri-o-release-1.20]# echo MONITOR | nc $POD_IP 6379
+OK
