# Installation Kubeadm 
## Prerequis 
### Config reseau 

#### Permettre à iptables de voir le  trafic ponté 

```sh

# activation du module netfilter

[root@dm1alx091 ~]$ cat <<EOF | sudo tee /etc/modules-load.d/br_netfilter.conf
br_netfilter
EOF
br_netfilter

[root@dm1alx091 ~]$ systemctl restart systemd-modules-load.service
[root@dm1alx091 ~]$ lsmod|grep netfilter
br_netfilter           22256  0 
bridge                151336  2 br_netfilter,ebtable_broute
# delta on dm1alx09x, absence de ebtable_broute
bridge                151336  1 br_netfilter

# Parametrage systemctl
[root@dm1alx091 ~]$ cat <<EOF | sudo tee /etc/sysctl.d/k8s.conf
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
net.ipv4.ip_forward = 1
fs.may_detach_mounts = 1
EOF

net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
net.ipv4.ip_forward = 1
fs.may_detach_mounts = 1


[root@dm1alx091 ~]$ sudo sysctl --system
* Applying /usr/lib/sysctl.d/00-system.conf ...
* Applying /usr/lib/sysctl.d/10-default-yama-scope.conf ...
kernel.yama.ptrace_scope = 0
* Applying /usr/lib/sysctl.d/50-default.conf ...
kernel.sysrq = 16
kernel.core_uses_pid = 1
kernel.kptr_restrict = 1
net.ipv4.conf.default.rp_filter = 1
net.ipv4.conf.all.rp_filter = 1
net.ipv4.conf.default.accept_source_route = 0
net.ipv4.conf.all.accept_source_route = 0
net.ipv4.conf.default.promote_secondaries = 1
net.ipv4.conf.all.promote_secondaries = 1
fs.protected_hardlinks = 1
fs.protected_symlinks = 1
* Applying /usr/lib/sysctl.d/99-containers.conf ...
fs.may_detach_mounts = 1
* Applying /etc/sysctl.d/99-sysctl.conf ...
* Applying /etc/sysctl.d/k8s.conf ...
* Applying /etc/sysctl.conf ...

```

### Addition of Kubernetes tools (kubeadm, kubectl...)
# Packages collected from dm1alx090:/applis/m1ad/r2prepo/packages

[root@dm1alx091 ~]$ sudo yum install *.rpm
Modules complémentaires chargés : product-id, search-disabled-repos, subscription-manager
Examen de 14bfe6e75a9efc8eca3f638eb22c7e2ce759c67f95b43b16fae4ebabde1549f3-cri-tools-1.13.0-0.x86_64.rpm : cri-tools-1.13.0-0.x86_64
Sélection de 14bfe6e75a9efc8eca3f638eb22c7e2ce759c67f95b43b16fae4ebabde1549f3-cri-tools-1.13.0-0.x86_64.rpm pour installation 
Examen de 312a0a10360c60167955721fefc5c0a8a606a3694f0b15afc669017c9a1e9375-kubelet-1.20.10-0.x86_64.rpm : kubelet-1.20.10-0.x86_64
Sélection de 312a0a10360c60167955721fefc5c0a8a606a3694f0b15afc669017c9a1e9375-kubelet-1.20.10-0.x86_64.rpm pour installation 
Examen de 4a2e03e921a596f5ad5bad9fef45b8c0d6195be4c4c67e145922d5a172bfcf81-kubectl-1.20.10-0.x86_64.rpm : kubectl-1.20.10-0.x86_64
Sélection de 4a2e03e921a596f5ad5bad9fef45b8c0d6195be4c4c67e145922d5a172bfcf81-kubectl-1.20.10-0.x86_64.rpm pour installation 
lSélection de 7712292d1b62752d63807929c5d9e9af7633161613d5b9482e814eb55fcb9ab7-kubeadm-1.20.10-0.x86_64.rpm pour installation 
Examen de db7cb5cb0b3f6875f54d10f02e625573988e3e91fd4fc5eef0b1876bb18604ad-kubernetes-cni-0.8.7-0.x86_64.rpm : kubernetes-cni-0.8.7-0.x86_64
Sélection de db7cb5cb0b3f6875f54d10f02e625573988e3e91fd4fc5eef0b1876bb18604ad-kubernetes-cni-0.8.7-0.x86_64.rpm pour installation 
Résolution des dépendances
--> Lancement de la transaction de test
---> Le paquet cri-tools.x86_64 0:1.13.0-0 sera installé
---> Le paquet kubeadm.x86_64 0:1.20.10-0 sera installé
---> Le paquet kubectl.x86_64 0:1.20.10-0 sera installé
---> Le paquet kubelet.x86_64 0:1.20.10-0 sera installé
--> Traitement de la dépendance : conntrack pour le paquet : kubelet-1.20.10-0.x86_64
rhel-7-server-extras-rpms                                                                                                                                                                                                                       | 3.4 kB  00:00:00     
rhel-7-server-optional-rpms                                                                                                                                                                                                                     | 3.2 kB  00:00:00     
rhel-7-server-rpms                                                                                                                                                                                                                              | 3.5 kB  00:00:00     
--> Traitement de la dépendance : socat pour le paquet : kubelet-1.20.10-0.x86_64
---> Le paquet kubernetes-cni.x86_64 0:0.8.7-0 sera installé
--> Lancement de la transaction de test
---> Le paquet conntrack-tools.x86_64 0:1.4.4-7.el7 sera installé
--> Traitement de la dépendance : libnetfilter_cthelper.so.0(LIBNETFILTER_CTHELPER_1.0)(64bit) pour le paquet : conntrack-tools-1.4.4-7.el7.x86_64
--> Traitement de la dépendance : libnetfilter_cttimeout.so.1(LIBNETFILTER_CTTIMEOUT_1.0)(64bit) pour le paquet : conntrack-tools-1.4.4-7.el7.x86_64
--> Traitement de la dépendance : libnetfilter_cttimeout.so.1(LIBNETFILTER_CTTIMEOUT_1.1)(64bit) pour le paquet : conntrack-tools-1.4.4-7.el7.x86_64
--> Traitement de la dépendance : libnetfilter_cthelper.so.0()(64bit) pour le paquet : conntrack-tools-1.4.4-7.el7.x86_64
--> Traitement de la dépendance : libnetfilter_cttimeout.so.1()(64bit) pour le paquet : conntrack-tools-1.4.4-7.el7.x86_64
--> Traitement de la dépendance : libnetfilter_queue.so.1()(64bit) pour le paquet : conntrack-tools-1.4.4-7.el7.x86_64
---> Le paquet socat.x86_64 0:1.7.3.2-2.el7 sera installé
--> Lancement de la transaction de test
---> Le paquet libnetfilter_cthelper.x86_64 0:1.0.0-11.el7 sera installé
---> Le paquet libnetfilter_cttimeout.x86_64 0:1.0.0-7.el7 sera installé
---> Le paquet libnetfilter_queue.x86_64 0:1.0.2-2.el7_2 sera installé
--> Résolution des dépendances terminée

Dépendances résolues

=======================================================================================================================================================================================================================================================================
Package                                             Architecture                        Version                                    Dépôt                                                                                                                        Taille
=======================================================================================================================================================================================================================================================================
Installation :
cri-tools                                           x86_64                              1.13.0-0                                   /14bfe6e75a9efc8eca3f638eb22c7e2ce759c67f95b43b16fae4ebabde1549f3-cri-tools-1.13.0-0.x86_64                                   21 M
kubeadm                                             x86_64                              1.20.10-0                                  /7712292d1b62752d63807929c5d9e9af7633161613d5b9482e814eb55fcb9ab7-kubeadm-1.20.10-0.x86_64                                    37 M
kubectl                                             x86_64                              1.20.10-0                                  /4a2e03e921a596f5ad5bad9fef45b8c0d6195be4c4c67e145922d5a172bfcf81-kubectl-1.20.10-0.x86_64                                    38 M
kubelet                                             x86_64                              1.20.10-0                                  /312a0a10360c60167955721fefc5c0a8a606a3694f0b15afc669017c9a1e9375-kubelet-1.20.10-0.x86_64                                   109 M
kubernetes-cni                                      x86_64                              0.8.7-0                                    /db7cb5cb0b3f6875f54d10f02e625573988e3e91fd4fc5eef0b1876bb18604ad-kubernetes-cni-0.8.7-0.x86_64                               55 M
Installation pour dépendances :
conntrack-tools                                     x86_64                              1.4.4-7.el7                                rhel-7-server-rpms                                                                                                           187 k
libnetfilter_cthelper                               x86_64                              1.0.0-11.el7                               rhel-7-server-rpms                                                                                                            18 k
libnetfilter_cttimeout                              x86_64                              1.0.0-7.el7                                rhel-7-server-rpms                                                                                                            18 k
libnetfilter_queue                                  x86_64                              1.0.2-2.el7_2                              rhel-7-server-rpms                                                                                                            23 k
socat                                               x86_64                              1.7.3.2-2.el7                              rhel-7-server-rpms                                                                                                           290 k

Résumé de la transaction
=======================================================================================================================================================================================================================================================================
Installation   5 Paquets (+5 Paquets en dépendance)

Taille totale  : 261 M
Taille totale des téléchargements : 535 k
Taille d'installation : 262 M
Is this ok [y/d/N]: y
Downloading packages:
(1/5): conntrack-tools-1.4.4-7.el7.x86_64.rpm                                                                                                                                                                                                   | 187 kB  00:00:01     
(2/5): libnetfilter_cthelper-1.0.0-11.el7.x86_64.rpm                                                                                                                                                                                            |  18 kB  00:00:01     
(3/5): libnetfilter_cttimeout-1.0.0-7.el7.x86_64.rpm                                                                                                                                                                                            |  18 kB  00:00:00     
(4/5): libnetfilter_queue-1.0.2-2.el7_2.x86_64.rpm                                                                                                                                                                                              |  23 kB  00:00:00     
(5/5): socat-1.7.3.2-2.el7.x86_64.rpm                                                                                                                                                                                                           | 290 kB  00:00:00     
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Total                                                                                                                                                                                                                                  203 kB/s | 535 kB  00:00:02     
Running transaction check
Running transaction test
Transaction test succeeded
Running transaction
  Installation : socat-1.7.3.2-2.el7.x86_64                                                                                                                                                                                                                       1/10 
  Installation : libnetfilter_cthelper-1.0.0-11.el7.x86_64                                                                                                                                                                                                        2/10 
  Installation : cri-tools-1.13.0-0.x86_64                                                                                                                                                                                                                        3/10 
  Installation : libnetfilter_cttimeout-1.0.0-7.el7.x86_64                                                                                                                                                                                                        4/10 
  Installation : libnetfilter_queue-1.0.2-2.el7_2.x86_64                                                                                                                                                                                                          5/10 
  Installation : conntrack-tools-1.4.4-7.el7.x86_64                                                                                                                                                                                                               6/10 
  Installation : kubernetes-cni-0.8.7-0.x86_64                                                                                                                                                                                                                    7/10 
  Installation : kubelet-1.20.10-0.x86_64                                                                                                                                                                                                                         8/10 
  Installation : kubectl-1.20.10-0.x86_64                                                                                                                                                                                                                         9/10 
  Installation : kubeadm-1.20.10-0.x86_64                                                                                                                                                                                                                        10/10 
  Vérification : kubectl-1.20.10-0.x86_64                                                                                                                                                                                                                         1/10 
  Vérification : conntrack-tools-1.4.4-7.el7.x86_64                                                                                                                                                                                                               2/10 
  Vérification : kubernetes-cni-0.8.7-0.x86_64                                                                                                                                                                                                                    3/10 
  Vérification : libnetfilter_queue-1.0.2-2.el7_2.x86_64                                                                                                                                                                                                          4/10 
  Vérification : kubelet-1.20.10-0.x86_64                                                                                                                                                                                                                         5/10 
  Vérification : libnetfilter_cttimeout-1.0.0-7.el7.x86_64                                                                                                                                                                                                        6/10 
  Vérification : cri-tools-1.13.0-0.x86_64                                                                                                                                                                                                                        7/10 
  Vérification : libnetfilter_cthelper-1.0.0-11.el7.x86_64                                                                                                                                                                                                        8/10 
  Vérification : socat-1.7.3.2-2.el7.x86_64                                                                                                                                                                                                                       9/10 
  Vérification : kubeadm-1.20.10-0.x86_64                                                                                                                                                                                                                        10/10 

Installé :
  cri-tools.x86_64 0:1.13.0-0                         kubeadm.x86_64 0:1.20.10-0                         kubectl.x86_64 0:1.20.10-0                         kubelet.x86_64 0:1.20.10-0                         kubernetes-cni.x86_64 0:0.8.7-0                        

Dépendances installées :
  conntrack-tools.x86_64 0:1.4.4-7.el7              libnetfilter_cthelper.x86_64 0:1.0.0-11.el7              libnetfilter_cttimeout.x86_64 0:1.0.0-7.el7              libnetfilter_queue.x86_64 0:1.0.2-2.el7_2              socat.x86_64 0:1.7.3.2-2.el7             

Terminé !



```

# Configration kubelet

```sh
cat <<EOF | sudo tee /etc/sysconfig/kubelet
KUBELET_EXTRA_ARGS=--feature-gates="AllAlpha=false,RunAsGroup=true" --container-runtime=remote --cgroup-driver=systemd --container-runtime-endpoint='unix:///var/run/crio/crio.sock' --runtime-request-timeout=5m
EOF

[ccohen@kubeadm01 cri-o] sudo systemctl daemon-reload &&  sudo systemctl enable kubelet

[ccohen@kubeadm01 cri-o] sudo systemctl disable --now firewalld 
Removed symlink /etc/systemd/system/multi-user.target.wants/firewalld.service.
Removed symlink /etc/systemd/system/dbus-org.fedoraproject.FirewallD1.service.
```


# init cluster 

## Preparation du fichier de config
```sh
cat <<EOF |  tee ~/kubeadm-init.conf
apiVersion: kubeadm.k8s.io/v1beta2
kind: ClusterConfiguration
kubernetesVersion: v1.20.10
imageRepository: dm1alx090.dns21.socgen/k8s
networking:
  podSubnet: 172.16.0.0/12
apiServer:
  certSANs:
  - "dm1alx094.dns21.socgen"
controlPlaneEndpoint: "dm1alx094.dns21.socgen:6443"
EOF

```

```sh
[root@kubeadm01 registries.d] kubeadm --config=kubeadm-init.conf
[init] Using Kubernetes version: v1.20.10
[preflight] Running pre-flight checks
[preflight] Pulling images required for setting up a Kubernetes cluster
[preflight] This might take a minute or two, depending on the speed of your internet connection
[preflight] You can also perform this action in beforehand using 'kubeadm config images pull'
[certs] Using certificateDir folder "/etc/kubernetes/pki"
[certs] Generating "ca" certificate and key
[certs] Generating "apiserver" certificate and key
[certs] apiserver serving cert is signed for DNS names [kubeadm01 kubernetes kubernetes.default kubernetes.default.svc kubernetes.default.svc.cluster.local] and IPs [10.96.0.1 192.168.60.2]
[certs] Generating "apiserver-kubelet-client" certificate and key
[certs] Generating "front-proxy-ca" certificate and key
[certs] Generating "front-proxy-client" certificate and key
[certs] Generating "etcd/ca" certificate and key
[certs] Generating "etcd/server" certificate and key
[certs] etcd/server serving cert is signed for DNS names [kubeadm01 localhost] and IPs [192.168.60.2 127.0.0.1 ::1]
[certs] Generating "etcd/peer" certificate and key
[certs] etcd/peer serving cert is signed for DNS names [kubeadm01 localhost] and IPs [192.168.60.2 127.0.0.1 ::1]
[certs] Generating "etcd/healthcheck-client" certificate and key
[certs] Generating "apiserver-etcd-client" certificate and key
[certs] Generating "sa" key and public key
[kubeconfig] Using kubeconfig folder "/etc/kubernetes"
[kubeconfig] Writing "admin.conf" kubeconfig file
[kubeconfig] Writing "kubelet.conf" kubeconfig file
[kubeconfig] Writing "controller-manager.conf" kubeconfig file
[kubeconfig] Writing "scheduler.conf" kubeconfig file
[kubelet-start] Writing kubelet environment file with flags to file "/var/lib/kubelet/kubeadm-flags.env"
[kubelet-start] Writing kubelet configuration to file "/var/lib/kubelet/config.yaml"
[kubelet-start] Starting the kubelet
[control-plane] Using manifest folder "/etc/kubernetes/manifests"
[control-plane] Creating static Pod manifest for "kube-apiserver"
[control-plane] Creating static Pod manifest for "kube-controller-manager"
[control-plane] Creating static Pod manifest for "kube-scheduler"
[etcd] Creating static Pod manifest for local etcd in "/etc/kubernetes/manifests"
[wait-control-plane] Waiting for the kubelet to boot up the control plane as static Pods from directory "/etc/kubernetes/manifests". This can take up to 4m0s
[apiclient] All control plane components are healthy after 22.505576 seconds
[upload-config] Storing the configuration used in ConfigMap "kubeadm-config" in the "kube-system" Namespace
[kubelet] Creating a ConfigMap "kubelet-config-1.20" in namespace kube-system with the configuration for the kubelets in the cluster
[upload-certs] Skipping phase. Please see --upload-certs
[mark-control-plane] Marking the node kubeadm01 as control-plane by adding the labels "node-role.kubernetes.io/master=''" and "node-role.kubernetes.io/control-plane='' (deprecated)"
[mark-control-plane] Marking the node kubeadm01 as control-plane by adding the taints [node-role.kubernetes.io/master:NoSchedule]
[bootstrap-token] Using token: g04pd0.dgcy9hlrlp2iwxe8
[bootstrap-token] Configuring bootstrap tokens, cluster-info ConfigMap, RBAC Roles
[bootstrap-token] configured RBAC rules to allow Node Bootstrap tokens to get nodes
[bootstrap-token] configured RBAC rules to allow Node Bootstrap tokens to post CSRs in order for nodes to get long term certificate credentials
[bootstrap-token] configured RBAC rules to allow the csrapprover controller automatically approve CSRs from a Node Bootstrap Token
[bootstrap-token] configured RBAC rules to allow certificate rotation for all node client certificates in the cluster
[bootstrap-token] Creating the "cluster-info" ConfigMap in the "kube-public" namespace
[kubelet-finalize] Updating "/etc/kubernetes/kubelet.conf" to point to a rotatable kubelet client certificate and key
[addons] Applied essential addon: CoreDNS
[addons] Applied essential addon: kube-proxy

Your Kubernetes control-plane has initialized successfully!

To start using your cluster, you need to run the following as a regular user:

  mkdir -p $HOME/.kube
  sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
  sudo chown $(id -u):$(id -g) $HOME/.kube/config

Alternatively, if you are the root user, you can run:

  export KUBECONFIG=/etc/kubernetes/admin.conf

You should now deploy a pod network to the cluster.
Run "kubectl apply -f [podnetwork].yaml" with one of the options listed at:
  https://kubernetes.io/docs/concepts/cluster-administration/addons/

Then you can join any number of worker nodes by running the following on each as root:

kubeadm join 192.168.60.2:6443 --token g04pd0.dgcy9hlrlp2iwxe8 \
    --discovery-token-ca-cert-hash sha256:68cf237b0c77af9a74a7e4b6c44a4d67b97a6ede201b7e61a963aade8c39e31b 

mkdir -p $HOME/.kube
sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
sudo chown $(id -u):$(id -g) $HOME/.kube/config

```


# Validation de l'install 

tous les pods doivent etre runing  pa de crashloop, ou autre
```sh 
[root@kubeadm01 ccohen]# kubectl get po -A 
NAMESPACE     NAME                                READY   STATUS    RESTARTS   AGE
kube-system   coredns-5dccb6d59b-9rcw2            1/1     Running   0          34s
kube-system   coredns-5dccb6d59b-nlx7n            1/1     Running   0          34s
kube-system   etcd-kubeadm01                      0/1     Running   0          35s
kube-system   kube-apiserver-kubeadm01            1/1     Running   0          35s
kube-system   kube-controller-manager-kubeadm01   1/1     Running   0          35s
kube-system   kube-proxy-282jq                    1/1     Running   0          34s
kube-system   kube-scheduler-kubeadm01            0/1     Running   0          35s

```


la commande kubectl get events -w -A   permet d\'afficher les evenements / erreurs  aidant à comprendre pourquoi les pods sont pas running

# Configuration network plugin 
## Récupération de Calico 

```sh
wget https://docs.projectcalico.org/v3.8/manifests/calico.yaml

```
## personnalisation du fichier 

modifier la valeur  de CALICO_IPV4POOL_CIDR pour qu'il match avec le cidr donné à kubeadm

## transfert sur la machine
```sh
rsync -avpP manifests/calico.yaml kubeadm01:~/
sending incremental file list
calico.yaml
         20,822 100%    0.00kB/s    0:00:00 (xfr#1, to-chk=0/1)

sent 20,935 bytes  received 35 bytes  41,940.00 bytes/sec
total size is 20,822  speedup is 0.99
```

## installation de calico
```sh
[root@kubeadm01 ~] kubectl apply -f ~/calico.yaml
configmap/calico-config created
Warning: apiextensions.k8s.io/v1beta1 CustomResourceDefinition is deprecated in v1.16+, unavailable in v1.22+; use apiextensions.k8s.io/v1 CustomResourceDefinition
customresourcedefinition.apiextensions.k8s.io/felixconfigurations.crd.projectcalico.org created
customresourcedefinition.apiextensions.k8s.io/ipamblocks.crd.projectcalico.org created
customresourcedefinition.apiextensions.k8s.io/blockaffinities.crd.projectcalico.org created
customresourcedefinition.apiextensions.k8s.io/ipamhandles.crd.projectcalico.org created
customresourcedefinition.apiextensions.k8s.io/ipamconfigs.crd.projectcalico.org created
customresourcedefinition.apiextensions.k8s.io/bgppeers.crd.projectcalico.org created
customresourcedefinition.apiextensions.k8s.io/bgpconfigurations.crd.projectcalico.org created
customresourcedefinition.apiextensions.k8s.io/ippools.crd.projectcalico.org created
customresourcedefinition.apiextensions.k8s.io/hostendpoints.crd.projectcalico.org created
customresourcedefinition.apiextensions.k8s.io/clusterinformations.crd.projectcalico.org created
customresourcedefinition.apiextensions.k8s.io/globalnetworkpolicies.crd.projectcalico.org created
customresourcedefinition.apiextensions.k8s.io/globalnetworksets.crd.projectcalico.org created
customresourcedefinition.apiextensions.k8s.io/networkpolicies.crd.projectcalico.org created
customresourcedefinition.apiextensions.k8s.io/networksets.crd.projectcalico.org created
clusterrole.rbac.authorization.k8s.io/calico-kube-controllers created
clusterrolebinding.rbac.authorization.k8s.io/calico-kube-controllers created
clusterrole.rbac.authorization.k8s.io/calico-node created
clusterrolebinding.rbac.authorization.k8s.io/calico-node created
daemonset.apps/calico-node created
serviceaccount/calico-node created
deployment.apps/calico-kube-controllers created
serviceaccount/calico-kube-controllers created
```

## validation 

```sh
[root@kubeadm01 ccohen]# kubectl get po -A -o wide 
NAMESPACE     NAME                                       READY   STATUS    RESTARTS   AGE     IP             NODE        NOMINATED NODE   READINESS GATES
kube-system   calico-kube-controllers-664c8dbb46-9gn7c   1/1     Running   0          77s     10.85.0.5      kubeadm01   <none>           <none>
kube-system   calico-node-qrc4p                          1/1     Running   0          77s     192.168.60.2   kubeadm01   <none>           <none>
kube-system   coredns-5dccb6d59b-9rcw2                   1/1     Running   0          5m46s   10.85.0.3      kubeadm01   <none>           <none>
kube-system   coredns-5dccb6d59b-nlx7n                   1/1     Running   0          5m46s   10.85.0.4      kubeadm01   <none>           <none>
kube-system   etcd-kubeadm01                             1/1     Running   0          5m47s   192.168.60.2   kubeadm01   <none>           <none>
kube-system   kube-apiserver-kubeadm01                   1/1     Running   0          5m47s   192.168.60.2   kubeadm01   <none>           <none>
kube-system   kube-controller-manager-kubeadm01          1/1     Running   0          5m47s   192.168.60.2   kubeadm01   <none>           <none>
kube-system   kube-proxy-282jq                           1/1     Running   0          5m46s   192.168.60.2   kubeadm01   <none>           <none>
kube-system   kube-scheduler-kubeadm01                   1/1     Running   0          5m47s   192.168.60.2   kubeadm01   <none>           <none>

```
1. tous les pods doivent etre running aucun crashloop ou autre ... 

2. on remarque  que les pods calico et coredns n'ont pas la bonne addresse Ip dans le bon range il est nécessaire de redémarrer le noeud  pour que la configuration  prenne effet 


après le reboot valider que les IPs ont bien  changés: 
```sh
[root@kubeadm01 ccohen]# kubectl get po -o wide  -A 
NAMESPACE     NAME                                       READY   STATUS    RESTARTS   AGE    IP              NODE        NOMINATED NODE   READINESS GATES
kube-system   calico-kube-controllers-664c8dbb46-9gn7c   1/1     Running   0          6m1s   172.28.32.193   kubeadm01   <none>           <none>
kube-system   coredns-5dccb6d59b-9rcw2                   1/1     Running   0          10m    172.28.32.194   kubeadm01   <none>           <none>
kube-system   coredns-5dccb6d59b-nlx7n                   1/1     Running   0          10m    172.28.32.195   kubeadm01   <none>           <none>

```

# ajout de noeud supplémentaires ( master )
## copie des certificats sur les 2 autres masters 

```sh
USER=ccohen # customizable
CONTROL_PLANE_IPS="192.168.60.3 192.168.60.4"
for host in ${CONTROL_PLANE_IPS}; do
    scp /etc/kubernetes/pki/ca.crt "${USER}"@$host:
    scp /etc/kubernetes/pki/ca.key "${USER}"@$host:
    scp /etc/kubernetes/pki/sa.key "${USER}"@$host:
    scp /etc/kubernetes/pki/sa.pub "${USER}"@$host:
    scp /etc/kubernetes/pki/front-proxy-ca.crt "${USER}"@$host:
    scp /etc/kubernetes/pki/front-proxy-ca.key "${USER}"@$host:
    scp /etc/kubernetes/pki/etcd/ca.crt "${USER}"@$host:etcd-ca.crt
    scp /etc/kubernetes/pki/etcd/ca.key "${USER}"@$host:etcd-ca.key
    scp /etc/kubernetes/admin.conf "${USER}"@$host:
done

```
/!\ Avertissement: N'utilisez que les certificats de la liste ci-dessus. kubeadm se chargera de générer le reste des certificats avec les SANs requis pour les instances du control plane qui se joignent. Si vous copiez tous les certificats par erreur, la création de noeuds supplémentaires pourrait échouer en raison d'un manque de SANs requis.


Copie des fichiers au bon endroit
```sh 
# à repeter  sur chaque noeuds
USER=ccohen # customizable
mkdir -p /etc/kubernetes/pki/etcd
mv /home/${USER}/ca.crt /etc/kubernetes/pki/
mv /home/${USER}/ca.key /etc/kubernetes/pki/
mv /home/${USER}/sa.pub /etc/kubernetes/pki/
mv /home/${USER}/sa.key /etc/kubernetes/pki/
mv /home/${USER}/front-proxy-ca.crt /etc/kubernetes/pki/
mv /home/${USER}/front-proxy-ca.key /etc/kubernetes/pki/
mv /home/${USER}/etcd-ca.crt /etc/kubernetes/pki/etcd/ca.crt
mv /home/${USER}/etcd-ca.key /etc/kubernetes/pki/etcd/ca.key
mv /home/${USER}/admin.conf /etc/kubernetes/admin.conf
```

il faut jouer la commmande kubeadm join ... fourni par le master si on l'a  pas noté  on peut la récupérer les elements:

## récupération du token
```sh
[root@kubeadm01 ~] kubeadm token list 
TOKEN                     TTL         EXPIRES                     USAGES                   DESCRIPTION                                                EXTRA GROUPS
0dbj2x.5vl2y0t6goc9d51g   12h         2021-09-15T22:44:01+02:00   authentication,signing   The default bootstrap token generated by 'kubeadm init'.   system:bootstrappers:kubeadm:default-node-token

```


/!\ si 24h se sont écoulé entre l'ajout du premier noeud et les autres il faut regénérer un token : 
```sh 
kubectl  token create
```

## récupération du sha256

```sh
[root@kubeadm01 ~] openssl x509 -pubkey -in /etc/kubernetes/pki/ca.crt | openssl rsa -pubin -outform der 2>/dev/null | openssl dgst -sha256 -hex | sed 's/^.* //'
341d052e58abdbb3e8ba12eec013c23fa042a39f108cc51e3e733bd189119b7d

```

## install master 

```sh
kubeadm join api.kthw.p.cohenc.fr:6443 --token t8hjy9.w94n0o2xfid4c5ay --discovery-token-ca-cert-hash sha256:d018999fa67757c070c6ca64900baa4fe6a983e9107fe4bd7ec20dc419768b64  --control-plane
```


## Permetre aux pod de se lancer sur les masters 

```sh
kubectl taint nodes --all node-role.kubernetes.io/master-
```
# flush iptables rules
```bash
iptables -F
iptables -X
iptables -t nat -F
iptables -t nat -X
iptables -t mangle -F
iptables -t mangle -X
iptables -P INPUT ACCEPT
iptables -P FORWARD ACCEPT
iptables -P OUTPUT ACCEPT

# verify
iptables -nvL
```
